package com.example.goldcalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etWeight, etGoldPrice;
    RadioGroup goldTypeGroup;
    RadioButton rbKeep, rbWear;
    Button btnCalculate, btnReset;
    TextView tvTotalGoldValue, tvUruf, tvZakatPayable, tvFinalZakat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Views
        etWeight = findViewById(R.id.etWeight);
        etGoldPrice = findViewById(R.id.etGoldPrice);
        goldTypeGroup = findViewById(R.id.goldTypeGroup);
        rbKeep = findViewById(R.id.rbKeep);
        rbWear = findViewById(R.id.rbWear);
        btnCalculate = findViewById(R.id.btnCalculate);
        btnReset = findViewById(R.id.btnReset);
        tvTotalGoldValue = findViewById(R.id.tvTotalGoldValue);
        tvUruf = findViewById(R.id.tvUruf);
        tvZakatPayable = findViewById(R.id.tvZakatPayable);
        tvFinalZakat = findViewById(R.id.tvFinalZakat);

        btnCalculate.setOnClickListener(v -> calculateZakat());
        btnReset.setOnClickListener(v -> resetAll());
    }

    private void calculateZakat() {
        String weightStr = etWeight.getText().toString();
        String priceStr = etGoldPrice.getText().toString();

        if(weightStr.isEmpty() || priceStr.isEmpty() || goldTypeGroup.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please enter all values and select gold type", Toast.LENGTH_SHORT).show();
            return;
        }

        double weight = Double.parseDouble(weightStr);
        double price = Double.parseDouble(priceStr);

        // Total value of gold
        double totalGoldValue = weight * price;
        tvTotalGoldValue.setText("Total Value of Gold: RM " + String.format("%.2f", totalGoldValue));

        // Determine uruf (X)
        double X = rbKeep.isChecked() ? 85 : 200;
        double goldMinusUruf = weight - X;
        if(goldMinusUruf < 0) goldMinusUruf = 0;
        tvUruf.setText("Gold weight minus uruf: " + String.format("%.2f", goldMinusUruf) + " g");

        // Zakat payable
        double zakatPayable = goldMinusUruf * price;
        tvZakatPayable.setText("Zakat Payable: RM " + String.format("%.2f", zakatPayable));

        // Total zakat
        double totalZakat = zakatPayable * 0.025;
        tvFinalZakat.setText("Total Zakat: RM " + String.format("%.2f", totalZakat));
    }

    private void resetAll() {
        etWeight.setText("");
        etGoldPrice.setText("");
        goldTypeGroup.clearCheck();
        tvTotalGoldValue.setText("Total Value of Gold: RM 0");
        tvUruf.setText("Gold weight minus uruf: 0");
        tvZakatPayable.setText("Zakat Payable: RM 0");
        tvFinalZakat.setText("Total Zakat (2.5%): RM 0");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.menu_about) {
            startActivity(new Intent(this, AboutActivity.class));
            return true;
        } else if(id == R.id.menu_share) {
            // Share intent
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            String shareMessage = "Check out AQ GOLD Zakat Calculator app!";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "Share via"));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
